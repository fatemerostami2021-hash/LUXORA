import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Eyebrow } from "@/components/Section";
import HeroStage from "@/components/hero/HeroStage";
import Kinetic from "@/components/Kinetic";
import { brandSlugs, categoryImages, demoProducts } from "@/data/demo";
import { IMG } from "@/data/images";
import { getDict, isLocale } from "@/lib/i18n";

export default async function Home({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const t = getDict(locale);
  const h = t.home;
  const shop = `/${locale}/shop`;
  const tiles = ["attachments_curling_barrel", "attachments_round_brush", "attachments_smoothing_brush", "attachments_volumizing", "attachments_storage_case"] as const;

  return (
    <>
      {/* 1. Hero: pinned 3D story (device + attachments), five scroll stages, one GSAP timeline */}
      <HeroStage t={h.hero} locale={locale} />

      {/* 2. Journey copy (plain, accessible text; the old flat-image parts layer was replaced by the 3D hero) */}
      <section aria-labelledby="journey-title" className="section-pad mx-auto max-w-5xl px-5 text-center">
        <p className="eyebrow">{h.journey.eyebrow}</p>
        <Kinetic as="h2" text={h.journey.title} className="mt-4" />
        <p data-reveal="0.1" className="lede mx-auto mt-6 max-w-2xl text-muted">{h.journey.text}</p>
        <ul className="mt-12 grid gap-4 md:grid-cols-3">
          {h.journey.points.map((pt, i) => (
            <li key={pt.head} data-reveal={i * 0.1} className="card p-6 text-center" data-tilt>
              <p className="font-display text-2xl font-semibold text-accent" style={{ fontFamily: "var(--font-display)" }}>{pt.head}</p>
              <p className="mt-2 text-sm text-muted">{pt.text}</p>
            </li>
          ))}
        </ul>
      </section>

      {/* 3. Categories */}
      <section className="section-pad mx-auto max-w-7xl px-5">
        <Kinetic as="h2" text={h.catsTitle} />
        <p data-reveal="0.1" className="mt-3 max-w-2xl text-muted">{h.catsText}</p>
        <ul className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-5">
          {h.cats.map((c, i) => (
            <li key={c} data-reveal={i * 0.08}>
              <Link href={shop} data-tilt className="card group relative block aspect-[3/4] overflow-hidden">
                <Image src={IMG[categoryImages[i]].src} alt="" fill sizes="(min-width:768px) 20vw, 45vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
                <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent p-4 text-base font-bold text-white">{c}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* 4. Attachments (from the concept board) */}
      <section className="section-pad mx-auto max-w-7xl px-5">
        <Eyebrow>{h.attachments.eyebrow}</Eyebrow>
        <Kinetic as="h2" text={h.attachments.title} className="mt-3" />
        <p data-reveal="0.1" className="mt-3 max-w-2xl text-muted">{h.attachments.text}</p>
        <div className="mt-10 grid gap-4 md:grid-cols-[1.7fr_1fr]">
          <div data-reveal="0" className="card overflow-hidden"><Image {...IMG.attachments_lineup} alt={h.attachments.lineupAlt} sizes="(min-width:768px) 55vw, 95vw" className="h-full w-full object-cover" /></div>
          <div data-reveal="0.1" className="card overflow-hidden"><Image {...IMG.attachments_case_scene} alt={h.attachments.caseAlt} sizes="(min-width:768px) 30vw, 95vw" className="h-full w-full object-cover" /></div>
        </div>
        <ul className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-5">
          {h.attachments.items.map((it, i) => (
            <li key={it.name} data-reveal={i * 0.07} data-tilt className="card overflow-hidden">
              <Image {...IMG[tiles[i]]} alt="" sizes="(min-width:768px) 18vw, 45vw" className="aspect-[9/10] w-full object-cover" />
              <div className="p-4"><p className="font-bold">{it.name}</p><p className="mt-1 text-sm text-muted">{it.text}</p></div>
            </li>
          ))}
        </ul>
      </section>

      {/* 5. Featured (demo) */}
      <section className="section-pad mx-auto max-w-7xl px-5">
        <Kinetic as="h2" text={h.featTitle} />
        <p data-reveal="0.1" className="mt-3 max-w-2xl text-muted">{h.featText}</p>
        <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {demoProducts.slice(0, 3).map((p, i) => (
            <li key={p.slug} data-reveal={i * 0.1} data-tilt className="card p-4">
              <Image {...IMG[p.image]} alt="" sizes="(min-width:1024px) 30vw, 90vw" className="aspect-square w-full rounded-xl object-cover" />
              <p className="mt-4 font-bold">{h.cats[p.category]}</p>
              <p className="text-xs text-muted">{t.shop.demoProduct}</p>
            </li>
          ))}
        </ul>
      </section>

      {/* 6. Brands */}
      <section className="section-pad mx-auto max-w-7xl px-5">
        <Kinetic as="h2" text={h.brandsTitle} />
        <p data-reveal="0.1" className="mt-3 max-w-2xl text-muted">{h.brandsText}</p>
        <ul className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
          {t.brands.items.map((b, i) => (
            <li key={brandSlugs[i]} data-reveal={i * 0.08}>
              <Link href={`/${locale}/brands`} className="card flex h-28 items-center justify-center text-xl font-extrabold tracking-wide transition-transform hover:-translate-y-1" dir="ltr">{b.name}</Link>
            </li>
          ))}
        </ul>
      </section>

      {/* 7. Editorial */}
      <section className="section-pad mx-auto max-w-7xl px-5">
        <div className="card grid items-center gap-10 overflow-hidden p-8 md:grid-cols-2 md:p-14">
          <div>
            <Kinetic as="h2" text={h.editTitle} />
            <p data-reveal="0.1" className="mt-4 max-w-xl text-muted">{h.editText}</p>
            <Link data-reveal="0.2" href={`/${locale}/about`} className="btn-ghost mt-8">{h.editCta}</Link>
          </div>
          <div data-reveal="0.1" className="relative">
            <Image {...IMG.editorial_styling_products} alt={h.alts.products} sizes="(min-width:768px) 40vw, 90vw" className="w-full rounded-2xl object-cover" />
            <Image {...IMG.editorial_gift_set} alt={h.alts.giftSet} sizes="30vw" className="absolute -bottom-6 -start-4 w-2/5 rounded-2xl border-4 border-bg object-cover shadow-xl" />
          </div>
        </div>
      </section>

      {/* 8. Final CTA */}
      <section className="relative mx-auto my-10 max-w-7xl overflow-hidden rounded-3xl px-5">
        <Image {...IMG.categories_tools_pedestals} alt={h.alts.tools} sizes="90vw" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-black/55" />
        <div className="relative mx-auto max-w-3xl px-5 py-24 text-center text-white">
          <Kinetic as="h2" text={h.finalTitle} className="text-white [&_.kin-em]:!text-[var(--accent-2)]" />
          <p data-reveal="0.1" className="mt-4 text-white/80">{h.finalText}</p>
          <Link data-reveal="0.2" href={shop} className="btn-primary mt-8">{h.finalCta}</Link>
        </div>
      </section>
    </>
  );
}
